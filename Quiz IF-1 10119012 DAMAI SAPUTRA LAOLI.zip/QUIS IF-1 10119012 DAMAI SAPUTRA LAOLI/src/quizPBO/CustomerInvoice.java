package quizPBO;

public interface CustomerInvoice {
    public String currentTime();
}
